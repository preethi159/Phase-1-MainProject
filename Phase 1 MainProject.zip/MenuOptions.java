package virtualkey;

public class MenuOptions {
	public static void printWelcomeScreen() {
		System.out.println("*****************************************************\n"
				+ "** Welcome to Lockedme.com \n" + "** This application was developed by Preethi Sundarraj \n"
				+ "*****************************************************\n");
		System.out.println("You can use this application to :-\n"
				+ "• Retrieve all file names in the \"MainProject\" folder\n"
				+ "• Search, add, or delete files in \"MainProject\" folder.\n"
				+ "\n**Please be careful to ensure the correct filename is provided for searching or deleting files.**\n");
		
	}

	public static void displayMenu() {
		String menu = "\n\n****** Select any option number from below and press Enter ******\n\n"
				+ "1) Retrieve all files inside \"MainProject\" folder\n" + "2) Display menu for File operations\n"
				+ "3) Exit program\n";
		System.out.println(menu);

	}

	public static void displayFileMenuOptions() {
		String fileMenu = "\n\n****** Select any option number from below and press Enter ******\n\n"
				+ "1) Add a file to \"MainProject\" folder\n" + "2) Delete a file from \"MainProject\" folder\n"
				+ "3) Search for a file from \"MainProject\" folder\n" + "4) Show Previous Menu\n"+ "5) Exit program\n";

		System.out.println(fileMenu);
	}

}


