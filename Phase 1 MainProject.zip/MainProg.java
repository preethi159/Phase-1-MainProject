package virtualkey;

public class MainProg {
public static void main(String[] args) {
		
		
		FileOperations.createMainFolderIfNotPresent("MainProject");
		
		MenuOptions.printWelcomeScreen();
		
		HandleOptions.handleWelcomeScreenInput();
	}

}
